local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('vehiclerepair:server:attemptRepair', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if Player then
        local cash = Player.PlayerData.money.cash
        local bank = Player.PlayerData.money.bank
        local cost = Config.RepairCost

        if cash >= cost then
            Player.Functions.RemoveMoney('cash', cost, "vehicle-repair")
            TriggerClientEvent('vehiclerepair:client:repairVehicle', src)
        elseif bank >= cost then
            Player.Functions.RemoveMoney('bank', cost, "vehicle-repair")
            TriggerClientEvent('vehiclerepair:client:repairVehicle', src)
        else
            TriggerClientEvent('QBCore:Notify', src, 'Not enough money!', 'error')
        end
    end
end)
