local QBCore = exports['qb-core']:GetCoreObject()

-- Create Blips
CreateThread(function()
    for _, coords in pairs(Config.RepairLocations) do
        local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
        SetBlipSprite(blip, Config.Blip.Sprite)
        SetBlipDisplay(blip, Config.Blip.Display)
        SetBlipScale(blip, Config.Blip.Scale)
        SetBlipColour(blip, Config.Blip.Color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(Config.Blip.Label)
        EndTextCommandSetBlipName(blip)
    end
end)

-- Interaction Loop
CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()

        if IsPedInAnyVehicle(ped, false) then
            local pos = GetEntityCoords(ped)

            for _, coords in pairs(Config.RepairLocations) do
                local dist = #(pos - coords)

                if dist < 10.0 then
                    sleep = 0
                    DrawMarker(Config.Marker.Type, coords.x, coords.y, coords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                        Config.Marker.Size.x, Config.Marker.Size.y, Config.Marker.Size.z, Config.Marker.Color.r,
                        Config.Marker.Color.g, Config.Marker.Color.b, Config.Marker.Color.a, false, true, 2, false, nil,
                        nil, false)

                    if dist < 3.0 then
                        exports['qb-core']:DrawText('[E] Repair Vehicle ($' .. Config.RepairCost .. ')', 'left')
                        if IsControlJustPressed(0, 38) then -- E key
                            TriggerServerEvent('vehiclerepair:server:attemptRepair')
                        end
                    else
                        exports['qb-core']:HideText()
                    end
                end
            end
        else
            exports['qb-core']:HideText()
        end
        Wait(sleep)
    end
end)

-- Repair Event
RegisterNetEvent('vehiclerepair:client:repairVehicle', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if not vehicle or vehicle == 0 then return end

    FreezeEntityPosition(vehicle, true)
    QBCore.Functions.Notify('Repairing Vehicle...', 'primary', 5000)

    SetTimeout(5000, function()
        SetVehicleFixed(vehicle)
        SetVehicleDeformationFixed(vehicle)
        SetVehicleDirtLevel(vehicle, 0.0)
        SetVehicleEngineHealth(vehicle, 1000.0)
        SetVehicleBodyHealth(vehicle, 1000.0)
        SetVehiclePetrolTankHealth(vehicle, 1000.0)
        FreezeEntityPosition(vehicle, false)
        QBCore.Functions.Notify('Vehicle Repaired!', 'success')
    end)
end)
