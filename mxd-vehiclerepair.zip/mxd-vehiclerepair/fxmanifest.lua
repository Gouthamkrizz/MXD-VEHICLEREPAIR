fx_version 'cerulean'
game 'gta5'

author 'Antigravity'
description 'QBCore Vehicle Repair Script'
version '1.0.0'

shared_script 'config.lua'

client_script 'client/main.lua'
server_script 'server/main.lua'

lua54 'yes'
