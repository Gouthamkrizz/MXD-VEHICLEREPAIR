Config = {}

Config.RepairCost = 6000 -- Cost to repair vehicle

Config.RepairLocations = {
    vector3(-337.0, -135.0, 39.0),   -- LSC Burton
    vector3(-1155.0, -2007.0, 13.0), -- LSC Airport
    vector3(734.0, -1085.0, 22.0),   -- LSC La Mesa
    vector3(1177.0, 2640.0, 37.0),   -- LSC Harmony
    vector3(108.0, 6624.0, 31.0),    -- LSC Paleto Bay
    vector3(110.1, 6626.5, 31.8),    -- Beeker's Garage
    vector3(538.0, -181.5, 54.0),     -- Auto Exotic
    vector3(-2184.2891, -410.7915, 13.0649)     -- Beach repair
}

Config.Blip = {
    Sprite = 446,
    Display = 4,
    Scale = 0.7,
    Color = 5,
    Label = "Vehicle Repair"
}

Config.Marker = {
    Type = 1, -- Cylinder
    Size = { x = 3.0, y = 3.0, z = 1.0 },
    Color = { r = 255, g = 0, b = 0, a = 100 }
}
